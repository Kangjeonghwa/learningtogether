# HW-13 : Self Study 6-7

i,k=0,0

i=0

for i in range(0,5):
    for k in range(0,4-i):
        print(' ',end=' ')
    for k in range(0,2*i+1):
        print('\u2665',end=' ')
    print()
for i in range(5,9):
    for k in range(0,i-4):
        print(' ',end=' ')
    for k in range(0,2*(9-i)-1):
        print('\u2665',end=' ')
    print()

# while i<9:
#     if i<5:
#         k=0
#         while k<4-i:
#             print(' ',end=' ')
#             k+=1
#         k=0
#         while k<i*2+1:
#             print('\u2605',end=' ')
#             k+=1
#     else:
#         k=0
#         while k<i-4:
#             print(' ',end=' ')
#             k+=1
#         k=0
#         while k<(9-i)*2-1:
#             print('\u2605',end=' ')
#             k+=1
#     print()
#     i+=1