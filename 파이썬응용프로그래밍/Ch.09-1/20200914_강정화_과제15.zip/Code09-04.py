def plus(v1,v2):
    result=0
    result=v1+v2
    return result

hap=0

hap=plus(100,200)
print("100과 200의 plus() 함수 결과는 %d"%hap)