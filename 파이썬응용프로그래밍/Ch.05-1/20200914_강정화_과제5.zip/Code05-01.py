# HW-1 : Code05-01.py

a=200
if a<100:
    print("100보다 작군요.")
print("거짓이므로 이 문장은 안보이겠죠??")

print("프로그램 끝")