# HW-4 : Code05-04.py

a=200

if a<100:
    print("100보다 작군요.")
    print("참이면 이 문장도 보이겠죠?")
else:
    print("100보다 크군요.")
    print("거짓이면 이 문장도 보이겠죠?")

print("프로그램 끝")