ss='파이썬짱!'

sslen=len(ss)
for i in range(0,sslen):
    print(ss[i]+'$',end='')