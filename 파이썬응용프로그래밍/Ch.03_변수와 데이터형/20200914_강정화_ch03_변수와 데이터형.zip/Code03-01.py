#HW-1: 교과서 63 페이지 Code03-01
print("%d"%123)
print("%5d"%123)
print("%05d"%123)

print("%f"%123.45)
print("%7.1f"%123.45)
print("%7.3f"%123.45)

print("%s"%"Python")
print("%10s"%"Python")