# H/W-1 : 삼항 연산자를 사용한 if문 (slide 1)

score = 55
res=''

res='합격' if score>=60 else '불합격'

print(res)