# HW-5:"매개변수에 기본값을 설정" (강의 비디오 참고)

hap3=lambda num1=10, num2=20:num1+num2
print(hap3())
print(hap3(100,200))