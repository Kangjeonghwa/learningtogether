# HW-4: def hap  (강의 비디오 참고)

def hap(num1, num2):
    res=num1+num2
    return res
print(hap(10,20))