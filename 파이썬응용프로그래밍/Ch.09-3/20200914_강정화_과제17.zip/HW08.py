# HW-8: "2행과 3행을 합친 코드" (강의 비디오 참고)

myList=[1,2,3,4,5]
myList=list(map(lambda num:num+10,myList))
print(myList)
