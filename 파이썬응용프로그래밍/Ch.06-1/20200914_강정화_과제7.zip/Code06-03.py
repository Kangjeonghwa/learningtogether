i, hap = 0,0

for i in range(501,1001,2):
    hap+=i

print("500에서 1000까지 합계: %d"%hap)