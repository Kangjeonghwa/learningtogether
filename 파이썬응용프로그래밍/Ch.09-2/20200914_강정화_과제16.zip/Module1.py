# HW-10 : Module1.py

def func1():
    print("Module1.py의 func1()이 호출됨.")

def func2():
    print("Module1.py의 func2()이 호출됨.")

def func3():
    print("Module1.py의 func3()이 호출됨.")