# HW-11 : A.py

import Module1

Module1.func1()
Module1.func2()
Module1.func3()